A Wikipedia search web app built using Django
